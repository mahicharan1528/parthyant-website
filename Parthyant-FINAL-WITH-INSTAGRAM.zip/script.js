document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('menuToggle');
  const nav = document.getElementById('navMenu');
  const dropdown = document.getElementById('verticalDropdown');
  const dropBtn = dropdown?.querySelector('.nav-drop-toggle');

  toggle?.addEventListener('click', () => nav?.classList.toggle('open'));

  dropBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    dropdown.classList.toggle('open');
    dropBtn.setAttribute('aria-expanded', dropdown.classList.contains('open') ? 'true' : 'false');
  });

  nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    nav.classList.remove('open');
  }));

  const items = document.querySelectorAll('.section, .vertical-card, .feature-card, .service-card, .step, .image-panel, .form-card, .cta');
  items.forEach((el, i) => {
    el.classList.add('reveal-ready');
    el.style.transitionDelay = `${Math.min(i * 45, 240)}ms`;
  });
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  items.forEach(el => observer.observe(el));
});
